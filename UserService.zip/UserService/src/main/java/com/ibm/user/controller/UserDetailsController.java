package com.ibm.user.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.user.bean.UserDetails;
import com.ibm.user.service.UserDetailsService;

@RestController
@RequestMapping("")
public class UserDetailsController {
	
	@Autowired
	UserDetailsService service;
	
	@RequestMapping("/users")
	Iterable<UserDetails> getAllUsers(){
		return service.getAllUsers();
	}
	@RequestMapping("/users/{id}")
	Optional<UserDetails> getUserById(@PathVariable String id){
		return service.getUserById(id);
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/users")
	boolean addUser(@RequestBody UserDetails user){
		return service.addUser(user);
	}
	
}
