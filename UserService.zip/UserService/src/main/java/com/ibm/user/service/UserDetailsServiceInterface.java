package com.ibm.user.service;

public interface UserDetailsServiceInterface {

}
